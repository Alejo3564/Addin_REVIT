@echo off
setlocal EnableDelayedExpansion

echo.
echo  ============================================================
echo   EGIS Smart Tools - Parameter Sync for Revit 2026
echo   Installer
echo  ============================================================
echo.

:: Get the folder where this .bat lives (no trailing backslash)
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

set "REVIT_VER=2026"
set "ADDIN_NAME=EgisParameterSync"
set "REVIT_ADDINS=%APPDATA%\Autodesk\Revit\Addins\%REVIT_VER%"
set "DEST=%REVIT_ADDINS%\%ADDIN_NAME%"

set "SRC_DLL=%HERE%\%ADDIN_NAME%\%ADDIN_NAME%.dll"
set "SRC_ADDIN=%HERE%\%ADDIN_NAME%.addin"
set "SRC_FOLDER=%HERE%\%ADDIN_NAME%"

echo  User:        %USERNAME%
echo  Source:      %HERE%
echo  Destination: %DEST%
echo.

:: -- Debug: show what we are looking for ------------------------------------
echo  Checking for DLL:   %SRC_DLL%
echo  Checking for ADDIN: %SRC_ADDIN%
echo.

:: -- Check DLL exists -------------------------------------------------------
if not exist "%SRC_DLL%" (
    echo  [ERROR] DLL not found: %SRC_DLL%
    echo.
    echo  Please compile the project in Visual Studio first:
    echo    1. Open EgisParameterSync.sln
    echo    2. Select Release ^| AnyCPU
    echo    3. Build ^> Build Solution
    echo    4. Copy bin\Release\net48\EgisParameterSync.dll
    echo         into: %SRC_FOLDER%\
    echo    5. Run this installer again.
    echo.
    pause & exit /b 1
)
echo  [OK] DLL found.

:: -- Check .addin exists ----------------------------------------------------
if not exist "%SRC_ADDIN%" (
    echo  [ERROR] .addin file not found: %SRC_ADDIN%
    pause & exit /b 1
)
echo  [OK] .addin found.

:: -- Create Revit Addins folder if needed -----------------------------------
if not exist "%REVIT_ADDINS%" (
    echo  [INFO] Creating: %REVIT_ADDINS%
    mkdir "%REVIT_ADDINS%"
    if errorlevel 1 (
        echo  [ERROR] Could not create Revit Addins folder.
        pause & exit /b 1
    )
)

:: -- Create plugin subfolder ------------------------------------------------
if not exist "%DEST%" (
    mkdir "%DEST%"
    echo  [OK] Created: %DEST%
) else (
    echo  [INFO] Destination exists. Overwriting files.
)

:: -- Copy .addin ------------------------------------------------------------
copy /Y "%SRC_ADDIN%" "%REVIT_ADDINS%\" >nul
if errorlevel 1 (
    echo  [ERROR] Failed to copy .addin
    pause & exit /b 1
)
echo  [OK] Copied: %ADDIN_NAME%.addin

:: -- Copy folder contents ---------------------------------------------------
xcopy /Y /E /I /Q "%SRC_FOLDER%\*.*" "%DEST%\" >nul
if errorlevel 1 (
    echo  [ERROR] Failed to copy plugin folder
    pause & exit /b 1
)
echo  [OK] Copied: %ADDIN_NAME%\ folder

:: -- Verify DLL arrived -----------------------------------------------------
if not exist "%DEST%\%ADDIN_NAME%.dll" (
    echo  [ERROR] DLL not found in destination after copy.
    pause & exit /b 1
)
echo  [OK] Verified: EgisParameterSync.dll in destination.

:: -- Done -------------------------------------------------------------------
echo.
echo  ============================================================
echo   Installation successful!
echo.
echo   Restart Revit 2026 to activate the add-in.
echo   Look for the "EGIS Smart Tools" tab in the ribbon.
echo  ============================================================
echo.
pause
endlocal